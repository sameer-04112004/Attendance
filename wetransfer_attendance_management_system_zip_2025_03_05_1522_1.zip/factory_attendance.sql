-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 05, 2025 at 04:18 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `factory_attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `check_in` datetime NOT NULL,
  `check_out` datetime DEFAULT NULL,
  `total_hours` time GENERATED ALWAYS AS (timediff(`check_out`,`check_in`)) VIRTUAL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `emp_id`, `check_in`, `check_out`, `created_at`) VALUES
(5, 10, '2025-03-02 15:39:28', '2025-03-02 15:39:39', '2025-03-02 10:09:28'),
(6, 1, '2025-03-02 17:32:08', '2025-03-02 17:32:11', '2025-03-02 12:02:08'),
(7, 7, '2025-03-02 18:33:13', '2025-03-02 18:33:37', '2025-03-02 13:03:13'),
(8, 7, '2025-03-02 18:33:42', NULL, '2025-03-02 13:03:42'),
(9, 11, '2025-03-03 17:57:30', '2025-03-03 17:57:33', '2025-03-03 12:27:30');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `emp_id` int(11) NOT NULL,
  `emp_name` varchar(100) DEFAULT NULL,
  `emp_email` varchar(100) DEFAULT NULL,
  `emp_phone` varchar(20) DEFAULT NULL,
  `emp_designation` varchar(50) DEFAULT NULL,
  `emp_date_joined` date DEFAULT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'Employee'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`emp_id`, `emp_name`, `emp_email`, `emp_phone`, `emp_designation`, `emp_date_joined`, `role`) VALUES
(1, 'sudharshan', 'sudharshan@gmail.com', '9988776655', 'Supervisor', '2023-02-05', 'Employee'),
(2, 'surya', 'surya@gmail.com', '1122', 'Manager', '2022-09-18', 'Employee'),
(3, 'Michael Johnson', 'michael.j@gmail.com', '9988776655', 'Technician', '2023-01-10', 'Employee'),
(5, 'Chris Brown', 'chris.brown@gmail.com', '9001234567', 'Technician', '2023-03-22', 'Employee'),
(6, 'Sophia Wilson', 'sophia.w@gmail.com', '9456783210', 'Receptionist', '2023-06-01', 'Employee'),
(7, 'David Clark', 'david.c@gmail.com', '9543217890', 'Electrician', '2023-04-15', 'Employee'),
(8, 'Olivia Taylor', 'olivia.taylor@gmail.com', '9234567890', 'Supervisor', '2022-12-10', 'Employee'),
(9, 'William Moore', 'william.moore@gmail.com', '9988123456', 'Technician', '2023-07-19', 'Employee');

-- --------------------------------------------------------

--
-- Table structure for table `leaveform`
--

CREATE TABLE `leaveform` (
  `leave_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `leave_type` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `reason` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  `request_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `leaveform`
--

INSERT INTO `leaveform` (`leave_id`, `emp_id`, `leave_type`, `start_date`, `end_date`, `reason`, `status`, `request_date`) VALUES
(1, 7, 'Sick Leave', '2025-03-15', '2025-03-22', 'i have severe fever  for 2 days', 'ok', '2025-03-02 12:10:52'),
(2, 5, 'Sick Leave', '2025-03-15', '2025-03-21', 'cold', 'Pending', '2025-03-02 13:04:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(1, 'admin', 'admin123', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `leaveform`
--
ALTER TABLE `leaveform`
  ADD PRIMARY KEY (`leave_id`),
  ADD KEY `leaveform_ibfk_1` (`emp_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `leaveform`
--
ALTER TABLE `leaveform`
  MODIFY `leave_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `leaveform`
--
ALTER TABLE `leaveform`
  ADD CONSTRAINT `leaveform_ibfk_1` FOREIGN KEY (`emp_id`) REFERENCES `employees` (`emp_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

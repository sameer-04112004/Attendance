﻿Imports MySql.Data.MySqlClient

Public Class Login
    Private Sub btnEmployeeLogin_Click(sender As Object, e As EventArgs) Handles btnEmployeeLogin.Click
        Dim attendanceForm As New Attendance()
        attendanceForm.Show()
        Me.Hide()
    End Sub

    Private Sub btnAdminLogin_Click(sender As Object, e As EventArgs) Handles btnAdminLogin.Click
        Dim adminLoginForm As New AdminLogin()
        adminLoginForm.Show()
        Me.Hide()
    End Sub
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Login
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Panel1 = New Panel()
        btnAdminLogin = New Button()
        btnEmployeeLogin = New Button()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Trebuchet MS", 12F)
        Label1.ForeColor = SystemColors.Control
        Label1.Location = New Point(-3, 15)
        Label1.Name = "Label1"
        Label1.Size = New Size(402, 26)
        Label1.TabIndex = 0
        Label1.Text = " Attendance Management System (Factory)"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = SystemColors.Highlight
        Panel1.Controls.Add(Label1)
        Panel1.Font = New Font("Trebuchet MS", 12F)
        Panel1.Location = New Point(1, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(396, 58)
        Panel1.TabIndex = 1
        ' 
        ' btnAdminLogin
        ' 
        btnAdminLogin.BackColor = SystemColors.Highlight
        btnAdminLogin.Font = New Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnAdminLogin.ForeColor = SystemColors.ButtonHighlight
        btnAdminLogin.Location = New Point(86, 141)
        btnAdminLogin.Name = "btnAdminLogin"
        btnAdminLogin.Size = New Size(226, 57)
        btnAdminLogin.TabIndex = 15
        btnAdminLogin.Text = "Admin Login"
        btnAdminLogin.UseVisualStyleBackColor = False
        ' 
        ' btnEmployeeLogin
        ' 
        btnEmployeeLogin.BackColor = Color.LimeGreen
        btnEmployeeLogin.Font = New Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnEmployeeLogin.ForeColor = SystemColors.ButtonHighlight
        btnEmployeeLogin.Location = New Point(86, 76)
        btnEmployeeLogin.Name = "btnEmployeeLogin"
        btnEmployeeLogin.Size = New Size(226, 59)
        btnEmployeeLogin.TabIndex = 16
        btnEmployeeLogin.Text = "Employee Login"
        btnEmployeeLogin.UseVisualStyleBackColor = False
        ' 
        ' Login
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(398, 215)
        Controls.Add(btnEmployeeLogin)
        Controls.Add(btnAdminLogin)
        Controls.Add(Panel1)
        Name = "Login"
        Text = "Login"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnAdminLogin As Button
    Friend WithEvents btnEmployeeLogin As Button
End Class

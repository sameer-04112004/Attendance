﻿Imports MySql.Data.MySqlClient

Public Class Attendance
    Dim conn As New MySqlConnection("server=localhost; user=root; password=; database=attendance_db")

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Try
            conn.Open()

            ' 1️⃣ Check if the user exists and fetch credentials
            Dim checkQuery As String = "SELECT * FROM employees WHERE username=@username AND password=@password"
            Dim checkCmd As New MySqlCommand(checkQuery, conn)
            checkCmd.Parameters.AddWithValue("@username", txtUsername.Text.Trim())
            checkCmd.Parameters.AddWithValue("@password", txtPassword.Text.Trim())
            Dim reader As MySqlDataReader = checkCmd.ExecuteReader()

            If Not reader.HasRows Then
                reader.Close()
                conn.Close()
                MessageBox.Show("Invalid username or password!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If
            reader.Close()

            ' 2️⃣ Check if the employee is already logged in (logout_time is NULL)
            Dim checkLoginStatus As String = "SELECT * FROM employees WHERE username=@username AND logout_time IS NULL"
            Dim checkStatusCmd As New MySqlCommand(checkLoginStatus, conn)
            checkStatusCmd.Parameters.AddWithValue("@username", txtUsername.Text.Trim())
            Dim statusReader As MySqlDataReader = checkStatusCmd.ExecuteReader()

            If statusReader.HasRows Then
                statusReader.Close()
                conn.Close()
                MessageBox.Show("You are already logged in!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If
            statusReader.Close()

            ' 3️⃣ Log the employee in by updating login_time
            Dim loginQuery As String = "UPDATE employees SET login_time=NOW(), logout_time=NULL WHERE username=@username"
            Dim loginCmd As New MySqlCommand(loginQuery, conn)
            loginCmd.Parameters.AddWithValue("@username", txtUsername.Text.Trim())

            If loginCmd.ExecuteNonQuery() > 0 Then
                MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Login failed!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            conn.Close()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Try
            conn.Open()

            ' ✅ Update logout_time only for currently logged-in users
            Dim logoutQuery As String = "UPDATE employees SET logout_time=NOW() WHERE username=@username AND logout_time IS NULL"
            Dim logoutCmd As New MySqlCommand(logoutQuery, conn)
            logoutCmd.Parameters.AddWithValue("@username", txtUsername.Text.Trim())

            If logoutCmd.ExecuteNonQuery() > 0 Then
                MessageBox.Show("Logout successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("You are not logged in!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            conn.Close()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Redirect to Login Form
        Dim loginForm As New Login()
        loginForm.Show()
        Me.Hide()
    End Sub
End Class

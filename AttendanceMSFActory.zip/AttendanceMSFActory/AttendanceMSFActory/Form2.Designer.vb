﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdminDashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        Label1 = New Label()
        btnViewAttendance = New Button()
        btnLogout = New Button()
        btnAddAdmin = New Button()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = SystemColors.Highlight
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(356, 60)
        Panel1.TabIndex = 0
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Trebuchet MS", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = SystemColors.Control
        Label1.Location = New Point(73, 16)
        Label1.Name = "Label1"
        Label1.Size = New Size(200, 28)
        Label1.TabIndex = 1
        Label1.Text = "Admin Dashboard"
        ' 
        ' btnViewAttendance
        ' 
        btnViewAttendance.BackColor = Color.LimeGreen
        btnViewAttendance.Font = New Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnViewAttendance.ForeColor = SystemColors.ButtonHighlight
        btnViewAttendance.Location = New Point(22, 85)
        btnViewAttendance.Name = "btnViewAttendance"
        btnViewAttendance.Size = New Size(177, 153)
        btnViewAttendance.TabIndex = 12
        btnViewAttendance.Text = " View Attendance"
        btnViewAttendance.UseVisualStyleBackColor = False
        ' 
        ' btnLogout
        ' 
        btnLogout.BackColor = Color.Red
        btnLogout.Font = New Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnLogout.ForeColor = SystemColors.ButtonHighlight
        btnLogout.Location = New Point(220, 85)
        btnLogout.Name = "btnLogout"
        btnLogout.Size = New Size(124, 67)
        btnLogout.TabIndex = 13
        btnLogout.Text = "Log-out"
        btnLogout.UseVisualStyleBackColor = False
        ' 
        ' btnAddAdmin
        ' 
        btnAddAdmin.BackColor = Color.DodgerBlue
        btnAddAdmin.Font = New Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnAddAdmin.ForeColor = SystemColors.ButtonHighlight
        btnAddAdmin.Location = New Point(220, 170)
        btnAddAdmin.Name = "btnAddAdmin"
        btnAddAdmin.Size = New Size(124, 68)
        btnAddAdmin.TabIndex = 14
        btnAddAdmin.Text = "Add Admin"
        btnAddAdmin.UseVisualStyleBackColor = False
        ' 
        ' AdminDashboard
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(356, 265)
        Controls.Add(btnAddAdmin)
        Controls.Add(btnLogout)
        Controls.Add(btnViewAttendance)
        Controls.Add(Panel1)
        Name = "AdminDashboard"
        Text = "Admin Dashboard"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents btnViewAttendance As Button
    Friend WithEvents btnLogout As Button
    Friend WithEvents btnAddAdmin As Button
End Class

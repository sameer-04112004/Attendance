﻿Imports MySql.Data.MySqlClient

Public Class AdminRegister
    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        Try
            Dim conn As New MySqlConnection("server=localhost;user id=root;password=;database=attendance_db")
            conn.Open()

            ' Check if username already exists
            Dim checkQuery As String = "SELECT COUNT(*) FROM admins WHERE username = @username"
            Dim checkCmd As New MySqlCommand(checkQuery, conn)
            checkCmd.Parameters.AddWithValue("@username", txtUsername.Text.Trim())

            Dim count As Integer = Convert.ToInt32(checkCmd.ExecuteScalar())

            If count > 0 Then
                MessageBox.Show("Username already exists! Choose a different one.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                ' Insert new admin
                Dim insertQuery As String = "INSERT INTO admins (username, password) VALUES (@username, @password)"
                Dim cmd As New MySqlCommand(insertQuery, conn)
                cmd.Parameters.AddWithValue("@username", txtUsername.Text.Trim())
                cmd.Parameters.AddWithValue("@password", txtPassword.Text.Trim())

                cmd.ExecuteNonQuery()
                MessageBox.Show("Admin Registered Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                ' Clear input fields
                txtUsername.Text = ""
                txtPassword.Text = ""

                ' Redirect back to Admin Dashboard
                Dim adminDash As New AdminDashboard()
                adminDash.Show()
                Me.Hide()
            End If

            conn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub



    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' Redirect to Admin Dashboard
        Dim adminDashboard As New AdminDashboard()
        adminDashboard.Show()
        Me.Hide()
    End Sub
End Class

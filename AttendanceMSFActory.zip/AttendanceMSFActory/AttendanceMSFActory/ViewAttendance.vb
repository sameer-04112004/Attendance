﻿Imports MySql.Data.MySqlClient

Public Class ViewAttendance
    Private Sub ViewAttendance_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadEmployeeAttendance()
        LoadAdminAttendance()
    End Sub

    Private Sub LoadEmployeeAttendance()
        Try
            Dim conn As New MySqlConnection("server=localhost;user id=root;password=;database=attendance_db")
            Dim query As String = "SELECT id, username, login_time, logout_time FROM employees"
            Dim adapter As New MySqlDataAdapter(query, conn)
            Dim dt As New DataTable()
            adapter.Fill(dt)
            dgvEmployee.DataSource = dt
        Catch ex As Exception
            MessageBox.Show("Error loading employee attendance: " & ex.Message)
        End Try
    End Sub

    Private Sub LoadAdminAttendance()
        Try
            Dim conn As New MySqlConnection("server=localhost;user id=root;password=;database=attendance_db")
            Dim query As String = "SELECT id, username, login_time, logout_time FROM admins"
            Dim adapter As New MySqlDataAdapter(query, conn)
            Dim dt As New DataTable()
            adapter.Fill(dt)
            dgvAdmin.DataSource = dt
        Catch ex As Exception
            MessageBox.Show("Error loading admin attendance: " & ex.Message)
        End Try
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Dim adminDashboard As New AdminDashboard()
        adminDashboard.Show()
        Me.Close()
    End Sub

    Public Sub LoadAdminAttendanceData()
        Try
            Dim query As String = "SELECT id, username, login_time, logout_time FROM admins ORDER BY login_time DESC"

            Using conn As New MySqlConnection("server=localhost;user=root;password=;database=attendance_db;")
                conn.Open()
                Dim adapter As New MySqlDataAdapter(query, conn)
                Dim dt As New DataTable()
                adapter.Fill(dt)
                dgvAdmin.DataSource = dt
            End Using
        Catch ex As Exception
            MessageBox.Show("Failed to load admin attendance data: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


End Class
